You are reviewing copy against Monzo's published Writing Principles
(https://monzo.com/tone-of-voice). The pattern checks have already run; do not repeat them.

Channel: marketing (guide dials: {'kindness': 'high', 'magic': 'medium', 'wit': 'medium'})

Answer each question below. For every 'No' or 'Unsure', quote the exact passage.
If you can't point to a passage, answer 'Yes'. Do not rewrite the whole piece.

1. Impact first: does the copy say how this affects the reader before explaining why Monzo did it?
   (Guide: "We can explain our reasoning, but need to explain the impact first.")
2. Sorry: is sorry used only where Monzo did something wrong, and said once?
   (Guide: if "we haven't done anything wrong... we shouldn't say sorry.")
3. Serious isn't formal: if the news is bad or sensitive, does the language stay warm and plain?
4. Idioms and references: would someone with English as a second language understand every idiom
   and cultural reference at first glance?
5. Humour fit: is the amount of wit right for this channel's dial? Is any joke the obvious one?
6. Punching down: is anyone (customers, groups, Monzo itself) the target of a joke?
7. Confidence: does anything read as arrogant, or as Monzo looking down on customers?
8. Jargon: is every financial or technical term explained in plain words?
9. Deeper emotions: if the copy touches money stress, shame or mental health, is it handled with care
   and without jokes?

Return a table: question number | Yes / No / Unsure | quoted passage | one-line reason.

--- COPY ---
Invest in what matters to you
Choose from a range of options to suit your interests, values, financial goals and the level of risk you’re happy with.
Simple, transparent fees and the option to invest as little as £1.
The value of your investments could go up or down and you could get back less than you put in.
You need a Monzo current account to use Investments. UK residents 18+. Ts&Cs apply.
Keep it simple with ready-made funds
Pick from diversified ready-made funds based on your attitude to risk.
Careful
You’re happy with potentially smaller returns for less risk. About 80% of money in this fund ends up in bonds, and about 20% in shares.
Balanced
You're aiming for a higher return than Careful, with a medium level of risk. Roughly 34% of money in here ends up in bonds, and about 66% in shares.
Adventurous
You’re happy taking more risk if it means your returns could be higher. 100% of money in this fund ends up in shares.
Or build your own portfolio
Focus on topics that interest you, emerging industries or certain parts of the world.
Tech focused
Some of the world’s biggest tech companies.
Blockchain creators
Companies developing blockchain and cryptocurrency tech.
Metaverse
Companies worked on digital tech like VR and gaming.
Global companies
The world’s biggest companies across global stock markets
British companies
Top 100 largest companies traded on the London Stock Exchange.
More to choose from
We have 17 investments in total. Check them out.
An account to suit you
Open your Investment account as a stocks and shares ISA, which lets you invest up to £20,000 a year tax-free. Or consider a General Investment Account if you’ve already used your ISA allowance.
You can also transfer your cash or stocks and shares ISA from another provider over to Monzo. It’ll give you a good idea of how you’re working towards your future goals.
The taxes you pay depend on your circumstances and rules could change in the future.
Feel confident in your choices
Let experts do the hard work for you
We're offering investments from BlackRock’s iShares range and beyond. They're one of the world’s largest fund managers, so your money’s in expert hands.
Level up your investment knowledge
Our bite-sized topics help you understand key elements of investing.
Get step-by-step support to invest
If you’re eligible, you can answer a few questions and we'll give you an investment suggestion that could work for you.
Simple, transparent fees
No minimum fees. No trading fees. No surprises. Just more of your money invested and working for you.
Straightforward platform fees
You’ll pay a 0.25% yearly fee on Monzo Investments plus ongoing fund management costs that depend on what you invest in.
Great value for beginners
We don’t charge minimum account fees, dealing fees or ‘admin’ fees that can quickly eat into your returns especially on smaller portfolios. What you see is what you pay with Monzo.
Reduced fees for larger portfolios
We’ll cap your investment fees at £250 a year. Whatever your balance grows to, you won’t pay more than that.
Invest automatically
Auto investing features allow you to set your investing habits and let them tick along in the background to achieve your longer term goals.
Turn on regular investing
Regularly drip feeding money into your investments could help you balance out ups and downs in the stock market that may come along.
Invest your spare change
When you spend, we’ll round up the spare change to the nearest pound. And once it reaches £1, we'll invest it on a set day each week.
Invest your interest
Automatically invest the interest you earn on your savings each month. No extra effort, just a simple way to keep building.
Not a Monzo customer yet?
To get started with Monzo Investments, all you need is our free Monzo current account, which is packed with helpful ways to manage your money.
It only takes minutes to apply, straight from the app.
Questions, meet answers
What type of account can I invest into?
You can invest with us through a stocks and shares ISA and a general investment account. You can pay into more than one of the same type of ISA in a tax year. But if you already have an existing Cash ISA or Stocks and Shares ISA, you can transfer it to us too and carry on building with us.
Are my investments locked away?
No, you can access your money at any point. But remember, investing is a long-term strategy, so if you think you’ll need your money often, it may be best to put it into an instant access savings account instead.
Choose your investments
Themed funds
Automation and robotics
Companies that supply and develop automation and robotics.
Clean energy
Companies involved in renewable energy.
Healthcare innovation
Companies transforming healthcare through research and tech.
Geographic funds
American companies
Largest 500 publicly traded companies in USA.
Emerging markets
Companies in different sectors from emerging markets countries.
European companies
Companies across various sectors from developed countries in Europe.
The world’s biggest companies across global stock markets.
Fixed-income and commodities
Short-term bonds
Bonds that mature within one year for low risk returns in line with interest rates.
Gold
Tracks the daily price of gold.
Silver
Tracks the daily price of silver.
iShares® and BlackRock® are trademarks of BlackRock, used under licence. BlackRock has no obligation or liability in connection with any product or service offered by Monzo.
The information on this website is Monzo’s. BlackRock isn't responsible or liable for it, and BlackRock don’t guarantee it’s accurate, complete or reliable.
This isn’t financial advice. If you’d like some, it’s best to speak to a financial adviser.
